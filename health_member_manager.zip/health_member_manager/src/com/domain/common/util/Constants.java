package com.domain.common.util;

public interface Constants {

	int ITEMS_PER_PAGE = 15;//한 페이지당 보여줄 item의 수.
	int PAGES_PER_PAGEGROUP = 10; //한 페이지 그룹당 묶을 페이지수.
}
