package com.domain.board.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

import com.mydomain.vo.Board;
import com.mydomain.vo.CodeTable;



public interface QABoardDao {

	
}













