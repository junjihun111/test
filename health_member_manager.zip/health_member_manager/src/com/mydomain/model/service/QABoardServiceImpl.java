package com.mydomain.model.service;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.mydomain.vo.Board;
import com.mydomain.vo.CodeTable;
import com.mydomain.vo.Member;


public class QABoardServiceImpl implements QABoardService{
	


}
