package test;

public class jiwoo {


	public static void main(String[] args) {
		System.out.println("박지박 박지박 꺼꾸로 해도 박지박 박지박 박지박 꺼꾸로 해도 박지박");
	}
}
